<?php


return [

	/*
    |--------------------------------------------------------------------------
    | E-mails transactionnels en direction de l'app
    |--------------------------------------------------------------------------
    |
    | Mails envoyés seulement aux clients de l'app. Par exemple les mails
	| envoyés depuis un formulaire de contact
    |
    */

	'default' => 'admin@example.com',

];
