window._ = require('lodash');

window.slugify = require('slugify');

window.$ = window.jQuery = require('jquery');

window.Popper = require('popper.js').default;

require('bootstrap');

window.toastr = require('toastr');

require('../common');
