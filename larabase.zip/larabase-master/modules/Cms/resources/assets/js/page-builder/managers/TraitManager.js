export default {
	textNoElement: 'Sélectionnez un élément avant d\'utiliser l\'Éditeur de propriété',
}
