export default {
	name: 'Mobile',
	width: '320px',
	widthMedia: '576px',
}
