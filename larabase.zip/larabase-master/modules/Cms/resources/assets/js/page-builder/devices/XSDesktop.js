export default {
	name: 'XSDesktop',
	width: '1200px',
	widthMedia: '1199px) and (min-width:992px'
}
