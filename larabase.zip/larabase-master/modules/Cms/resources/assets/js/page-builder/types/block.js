export default editor => {
	editor.DomComponents.addType('block', {});
}
