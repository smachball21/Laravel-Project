export default {
	name: 'XSTablet',
	width: '768px',
	widthMedia: '767px) and (min-width:577px'
}
