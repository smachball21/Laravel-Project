export default {
	name: 'Tablet',
	width: '992px',
	widthMedia: '991px) and (min-width:768px'
}
