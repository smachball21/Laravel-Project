export default {
	name: 'Desktop',
	width: '', // default size
}
