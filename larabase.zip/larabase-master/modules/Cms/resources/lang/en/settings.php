<?php

return [
	'layout_editable' => [
		'title' => 'Modifier le HTML des pages',
		'desc'  => 'The layout and HTML structure of CMS pages are editable. <br> Developers are not affected by this option and still have this right.',
	],
];
