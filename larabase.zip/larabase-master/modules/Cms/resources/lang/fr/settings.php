<?php

return [
	'layout_editable' => [
		'title' => 'Modifier le HTML des pages',
		'desc'  => 'Le layout et la structure HTML des pages CMS sont modifiables.<br>Les développeurs ne sont pas affectés par cette option et possèdent toujours ce droit.',
	],
];
