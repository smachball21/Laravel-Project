<?php

namespace App\Services\Form\Traits;

/**
 * @version 0.1
 *
 * @author Alexis Weber
 */
trait HasAttributes
{

}
