<?php

namespace App\Services\Form\Interfaces;

/**
 * @version 0.1
 *
 * @author Alexis Weber
 */
interface FieldInterface
{
	public function render();
}
